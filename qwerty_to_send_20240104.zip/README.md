# qwerty-game

Rythm game about a little robot. Like FnF but better, and open-source!

## Credits
- Programming: [lonelymelon07](https://github.com/lonelymelon07/)
- Art & Story: [Cooblik](https://www.youtube.com/@cooblik)
- Music: [okhertz](https://okhertz.bandcamp.com/)
- Moral Support: [Icarus](https://www.youtube.com/@icarus3887)
